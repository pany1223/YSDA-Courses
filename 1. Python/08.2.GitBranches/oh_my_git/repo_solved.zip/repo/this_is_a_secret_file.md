Okay, you are lucky this time, and the code is  
`Haha, gotcha!`
No cheating, please, each student should find the code himself!
